for (let i = 1; i <= 3; i++) {
  for (let k = 1; k <= 2; k++) {
    document.write(`${i}행 ${k}열 <br/>`);
  }
  document.write("<br/>")
}
